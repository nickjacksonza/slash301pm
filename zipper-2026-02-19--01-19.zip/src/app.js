// ============================================================================
// APP ENTRY POINT (Phase 2 - Consolidated 5-Tab Navigation)
// ============================================================================
//
// Navigation structure:
// 1. DASHBOARD - Role-based landing page
// 2. WORK - Unified Projects/Jobs/Assets view
// 3. CAPACITY - Traffic/PM workload view
// 4. REVIEWS - Unified Internal/Client review
// 5. MORE (dropdown) - People, Wiki, Operations
// ============================================================================

const {
  useRef
} = React;

// BUG-02 fix: Error Boundary to catch render crashes and show fallback UI
class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }
  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }
  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary caught:', error, errorInfo);
  }
  render() {
    if (this.state.hasError) {
      return /*#__PURE__*/React.createElement("div", {
        style: { padding: '2rem', textAlign: 'center', color: '#666' }
      }, /*#__PURE__*/React.createElement("h2", null, "Something went wrong"),
      /*#__PURE__*/React.createElement("p", null, "An error occurred while rendering this view."),
      /*#__PURE__*/React.createElement("button", {
        className: "btn btn-primary",
        onClick: () => this.setState({ hasError: false, error: null }),
        style: { marginTop: '1rem' }
      }, "Try Again"),
      /*#__PURE__*/React.createElement("button", {
        className: "btn btn-secondary",
        onClick: () => window.location.reload(),
        style: { marginTop: '1rem', marginLeft: '0.5rem' }
      }, "Reload Page"));
    }
    return this.props.children;
  }
}

function App() {
  const [data, dispatch] = useReducer(dataReducer, null, loadFromStorage);
  const [activeTab, setActiveTab] = useState('Dashboard');
  const [viewMode, setViewMode] = useState('table'); // 'table' or 'kanban'
  const [searchQuery, setSearchQuery] = useState('');
  const [briefModalOpen, setBriefModalOpen] = useState(false);
  const [addPersonModalOpen, setAddPersonModalOpen] = useState(false);
  const [selectedItem, setSelectedItem] = useState(null);
  const [detailPanelOpen, setDetailPanelOpen] = useState(false);
  const [storageError, setStorageError] = useState(null);

  // Check for storage errors after data changes
  useEffect(() => {
    const error = getLastStorageError();
    if (error) {
      setStorageError(error);
      clearLastStorageError();
    }
  }, [data]);

  // Current user state - defaults to first user, stored in localStorage
  const [currentUserId, setCurrentUserId] = useState(() => {
    const saved = localStorage.getItem('slash301pm_currentUser');
    return saved || data?.people?.[0]?.id || 'p1';
  });

  // Get current user object
  const currentUser = data?.people?.find(p => p.id === currentUserId) || data?.people?.[0];

  // Save current user to localStorage when changed
  const handleUserChange = userId => {
    setCurrentUserId(userId);
    localStorage.setItem('slash301pm_currentUser', userId);
  };

  // Get permissions for current user
  const userPermissions = getUserPermissions(currentUser);
  const handleRowClick = item => {
    setSelectedItem(item);
    setDetailPanelOpen(true);
  };
  const handleExport = () => {
    const json = JSON.stringify(data, null, 2);
    const blob = new Blob([json], {
      type: 'application/json'
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `slash301pm-export-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };
  const handleImport = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';
    input.onchange = e => {
      const file = e.target.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = event => {
        try {
          const imported = JSON.parse(event.target.result);
          if (imported.people && imported.projects && imported.jobs && imported.assets) {
            dispatch({
              type: 'SET_DATA',
              payload: imported
            });
            alert('Data imported successfully!');
          } else {
            alert('Invalid file format');
          }
        } catch (err) {
          alert('Failed to parse file: ' + err.message);
        }
      };
      reader.readAsText(file);
    };
    input.click();
  };

  // Check if user can access Reviews tab
  const canAccessReviews = canAccessJobReview(currentUser) || canAccessClientReview(currentUser);

  // Get tab counts for badges
  const getTabCount = tab => {
    switch (tab) {
      case 'Dashboard':
        return null;
      // No count for dashboard
      case 'Work':
        return data.jobs.length;
      case 'Capacity':
        return data.people.filter(p => p.role !== 'Client').length;
      case 'Reviews':
        {
        // BUG-06/07 fix: Count internal review items + client review items (broadened filters)
        const reviewableStatuses = ['In Progress', 'Today', 'This Week', 'In Review'];
        const internalCount = data.jobs.filter(j => {
          if (!reviewableStatuses.includes(j.status)) return false;
          if (j.internalApprovedBy) return false;
          const jobTasks = (data.tasks || []).filter(t => t.jobId === j.id);
          const copyComplete = jobTasks.find(t => t.templateId === 'copy')?.status === 'Done';
          const mediaComplete = jobTasks.find(t => t.templateId === 'media')?.status === 'Done';
          return copyComplete && mediaComplete;
        }).length;
        const clientReviewStatuses = ['Approved (Internal)', 'In Review'];
        const clientCount = data.jobs.filter(j => clientReviewStatuses.includes(j.status) && j.assignments?.Client === currentUser?.id).length;
        return internalCount + clientCount;
        }
      default:
        return null;
    }
  };

  // Filter main tabs based on permissions
  const getVisibleMainTabs = () => {
    return MAIN_TABS.filter(tab => {
      // Hide Reviews if user has no access
      if (tab === 'Reviews' && !canAccessReviews) {
        return false;
      }
      // Hide Capacity from non-manager roles (optional - can be removed if you want all to see)
      // if (tab === 'Capacity' && !['COO', 'PM', 'Traffic', 'ECD', 'CD', 'Producer'].includes(currentUser?.role)) {
      //   return false;
      // }
      return true;
    });
  };

  // Check if active tab is in "More" menu
  const isMoreMenuActive = MORE_MENU_ITEMS.includes(activeTab);

  // Determine the detail panel type based on active tab
  const getDetailPanelType = () => {
    if (activeTab === 'Work') {
      // For Work tab, we need to determine the actual item type
      if (selectedItem?.jobNumber) return 'Jobs';
      if (selectedItem?.projectId && !selectedItem?.jobNumber) return 'Assets';
      if (selectedItem?.client) return 'Projects';
      return 'Jobs';
    }
    return activeTab;
  };
  return /*#__PURE__*/React.createElement("div", {
    className: "app-container"
  }, /*#__PURE__*/React.createElement(StorageWarning, {
    error: storageError,
    onDismiss: () => setStorageError(null),
    onExport: handleExport
  }), /*#__PURE__*/React.createElement("header", {
    className: "app-header"
  }, /*#__PURE__*/React.createElement("div", {
    className: "header-left"
  }, /*#__PURE__*/React.createElement("h1", {
    className: "app-title"
  }, "Slash 301 PM")), /*#__PURE__*/React.createElement("div", {
    className: "header-center"
  }, /*#__PURE__*/React.createElement("div", {
    className: "search-box"
  }, /*#__PURE__*/React.createElement("input", {
    type: "text",
    placeholder: "Search...",
    value: searchQuery,
    onChange: e => setSearchQuery(e.target.value)
  }))), /*#__PURE__*/React.createElement("div", {
    className: "header-right"
  }, activeTab === 'Work' && /*#__PURE__*/React.createElement("div", {
    className: "view-toggle"
  }, /*#__PURE__*/React.createElement("button", {
    className: viewMode === 'table' ? 'active' : '',
    onClick: () => setViewMode('table'),
    title: "Table View"
  }, /*#__PURE__*/React.createElement("span", {
    className: "icon-table"
  }, "\u2630")), /*#__PURE__*/React.createElement("button", {
    className: viewMode === 'kanban' ? 'active' : '',
    onClick: () => setViewMode('kanban'),
    title: "Kanban View"
  }, /*#__PURE__*/React.createElement("span", {
    className: "icon-kanban"
  }, "\u25A6"))), userPermissions.level === 'superadmin' && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("button", {
    className: "btn btn-icon",
    onClick: handleExport,
    title: "Export JSON"
  }, "\u2193"), /*#__PURE__*/React.createElement("button", {
    className: "btn btn-icon",
    onClick: handleImport,
    title: "Import JSON"
  }, "\u2191")), activeTab === 'People' && userPermissions.canEditPeople && /*#__PURE__*/React.createElement("button", {
    className: "btn btn-primary",
    onClick: () => setAddPersonModalOpen(true)
  }, "+ Add Person"), /*#__PURE__*/React.createElement(UserSelector, {
    people: data.people,
    currentUser: currentUser,
    onUserChange: handleUserChange
  }))), /*#__PURE__*/React.createElement("nav", {
    className: "tab-bar"
  }, getVisibleMainTabs().map(tab => /*#__PURE__*/React.createElement("button", {
    key: tab,
    className: `tab ${activeTab === tab ? 'active' : ''}`,
    onClick: () => setActiveTab(tab)
  }, /*#__PURE__*/React.createElement("span", {
    className: "tab-icon"
  }, TAB_ICONS[tab]), tab, getTabCount(tab) !== null && /*#__PURE__*/React.createElement("span", {
    className: "tab-count"
  }, getTabCount(tab)))), /*#__PURE__*/React.createElement(MoreMenu, {
    data: data,
    currentUser: currentUser,
    activeItem: isMoreMenuActive ? activeTab : null,
    onItemSelect: setActiveTab
  })), /*#__PURE__*/React.createElement("main", {
    className: "main-content"
  }, activeTab === 'Dashboard' && /*#__PURE__*/React.createElement(Dashboard, {
    data: data,
    dispatch: dispatch,
    currentUser: currentUser,
    onNewBrief: () => setBriefModalOpen(true),
    onCheckCapacity: () => setActiveTab('Capacity'),
    onJobClick: handleRowClick
  }), activeTab === 'Work' && /*#__PURE__*/React.createElement(ErrorBoundary, null, /*#__PURE__*/React.createElement(WorkTab, {
    data: data,
    dispatch: dispatch,
    currentUser: currentUser,
    viewMode: viewMode,
    searchQuery: searchQuery,
    onRowClick: handleRowClick,
    onNewBrief: () => setBriefModalOpen(true)
  })), activeTab === 'Capacity' && /*#__PURE__*/React.createElement(CapacityTab, {
    data: data,
    dispatch: dispatch,
    people: data.people
  }), activeTab === 'Reviews' && /*#__PURE__*/React.createElement(ReviewsTab, {
    data: data,
    dispatch: dispatch,
    currentUser: currentUser
  }), activeTab === 'People' && /*#__PURE__*/React.createElement(TableView, {
    tab: "People",
    data: data,
    dispatch: dispatch,
    people: data.people,
    projects: data.projects,
    onRowClick: handleRowClick,
    searchQuery: searchQuery,
    currentUser: currentUser
  }), activeTab === 'Wiki' && /*#__PURE__*/React.createElement(WikiTab, {
    data: data,
    dispatch: dispatch,
    people: data.people
  }), activeTab === 'Operations' && /*#__PURE__*/React.createElement(OperationsDashboard, {
    data: data,
    currentUser: currentUser
  })), /*#__PURE__*/React.createElement(BriefModal, {
    isOpen: briefModalOpen,
    onClose: () => setBriefModalOpen(false),
    data: data,
    dispatch: dispatch
  }), /*#__PURE__*/React.createElement(AddPersonModal, {
    isOpen: addPersonModalOpen,
    onClose: () => setAddPersonModalOpen(false),
    dispatch: dispatch
  }), /*#__PURE__*/React.createElement(DetailPanel, {
    item: selectedItem,
    type: getDetailPanelType(),
    isOpen: detailPanelOpen,
    onClose: () => {
      setDetailPanelOpen(false);
      setSelectedItem(null);
    },
    data: data,
    dispatch: dispatch,
    people: data.people,
    currentUser: currentUser
  }));
}

// Render the app
ReactDOM.createRoot(document.getElementById('root')).render(/*#__PURE__*/React.createElement(App, null));

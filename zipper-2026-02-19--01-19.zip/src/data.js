// ============================================================================
// SCHEMA VERSION & MIGRATIONS
// ============================================================================

const SCHEMA_VERSION = 1;

// Migration functions: each migrates from version N to N+1
const migrations = {
  // Example for future use:
  // 1: (data) => {
  //   // Migrate from v1 to v2
  //   data.newField = 'default';
  //   return data;
  // },
};

// Run all necessary migrations to bring data up to current version
const migrateData = data => {
  const dataVersion = data._schemaVersion || 0;
  if (dataVersion === SCHEMA_VERSION) {
    return data; // Already up to date
  }
  if (dataVersion > SCHEMA_VERSION) {
    console.warn(`Data schema version (${dataVersion}) is newer than app version (${SCHEMA_VERSION}). This may cause issues.`);
    return data;
  }
  let migratedData = {
    ...data
  };

  // Run each migration in sequence
  for (let v = dataVersion; v < SCHEMA_VERSION; v++) {
    if (migrations[v]) {
      console.log(`Migrating data from schema v${v} to v${v + 1}`);
      migratedData = migrations[v](migratedData);
    }
  }
  migratedData._schemaVersion = SCHEMA_VERSION;
  return migratedData;
};

// ============================================================================
// INITIAL/MOCK DATA
// ============================================================================

const createInitialData = () => ({
  _schemaVersion: SCHEMA_VERSION,
  people: [{
    id: 'p0',
    name: 'Rachel Adams',
    email: 'rachel@agency.com',
    role: 'COO',
    color: '#dc2626'
  }, {
    id: 'p1',
    name: 'Sarah Chen',
    email: 'sarah@agency.com',
    role: 'PM',
    color: '#3b82f6'
  }, {
    id: 'p2',
    name: 'James Wilson',
    email: 'james@agency.com',
    role: 'ECD',
    color: '#8b5cf6'
  }, {
    id: 'p3',
    name: 'Maria Garcia',
    email: 'maria@agency.com',
    role: 'CD',
    color: '#ec4899'
  }, {
    id: 'p4',
    name: 'Alex Thompson',
    email: 'alex@agency.com',
    role: 'Copywriter',
    color: '#f97316'
  }, {
    id: 'p5',
    name: 'Kim Lee',
    email: 'kim@agency.com',
    role: 'Designer',
    color: '#14b8a6'
  }, {
    id: 'p6',
    name: 'Jordan Blake',
    email: 'jordan@agency.com',
    role: 'QA',
    color: '#6366f1'
  }, {
    id: 'p7',
    name: 'Chris Martin',
    email: 'chris@client.com',
    role: 'Client',
    color: '#84cc16'
  }, {
    id: 'p8',
    name: 'Taylor Swift',
    email: 'taylor@agency.com',
    role: 'Producer',
    color: '#f43f5e'
  }, {
    id: 'p9',
    name: 'Morgan Davis',
    email: 'morgan@agency.com',
    role: 'Traffic',
    color: '#0ea5e9'
  }],
  projects: [{
    id: 'proj1',
    name: 'Summer Campaign',
    client: 'Acme Corp',
    description: 'Q3 summer product launch',
    status: 'In Progress',
    jobCount: 3,
    createdAt: '2024-01-15',
    clientColors: {
      primary: '#d4847a',
      secondary: '#c9a86c'
    }
  }, {
    id: 'proj2',
    name: 'Brand Refresh',
    client: 'TechStart',
    description: 'Complete brand identity overhaul',
    status: 'In Review',
    jobCount: 2,
    createdAt: '2024-01-20',
    clientColors: {
      primary: '#7a9bc4',
      secondary: '#a890c4'
    }
  }],
  jobs: [{
    id: 'job1',
    jobNumber: 'SUMM-001',
    name: 'Hero Video',
    description: 'Main campaign hero video',
    projectId: 'proj1',
    status: 'In Progress',
    assignments: {
      PM: 'p1',
      Traffic: 'p9',
      ECD: 'p2',
      CD: 'p3',
      Copywriter: 'p4',
      Designer: 'p5',
      QA: 'p6',
      Client: 'p7',
      Producer: 'p8'
    },
    dueDate: '2024-02-15',
    order: 0,
    createdAt: '2024-01-16'
  }, {
    id: 'job2',
    jobNumber: 'SUMM-002',
    name: 'Social Package',
    description: 'Social media content suite',
    projectId: 'proj1',
    status: 'Today',
    assignments: {
      PM: 'p1',
      Traffic: 'p1',
      ECD: 'p2',
      CD: 'p3',
      Copywriter: 'p4',
      Designer: 'p5',
      QA: 'p6',
      Client: 'p7',
      Producer: 'p8'
    },
    dueDate: '2024-02-10',
    order: 1,
    createdAt: '2024-01-17'
  }, {
    id: 'job3',
    jobNumber: 'SUMM-003',
    name: 'Email Campaign',
    description: 'Drip email sequence',
    projectId: 'proj1',
    status: 'Inbox',
    assignments: {
      PM: 'p1',
      Traffic: 'p9',
      ECD: 'p2',
      CD: 'p3',
      Copywriter: 'p4',
      Designer: 'p5',
      QA: 'p6',
      Client: 'p7',
      Producer: 'p8'
    },
    dueDate: '2024-02-20',
    order: 2,
    createdAt: '2024-01-18'
  }, {
    id: 'job4',
    jobNumber: 'BRAN-001',
    name: 'Logo Design',
    description: 'New logo concepts',
    projectId: 'proj2',
    status: 'In Review',
    assignments: {
      PM: 'p9',
      Traffic: 'p1',
      ECD: 'p2',
      CD: 'p3',
      Copywriter: 'p4',
      Designer: 'p5',
      QA: 'p6',
      Client: 'p7',
      Producer: 'p8'
    },
    dueDate: '2024-02-05',
    order: 0,
    createdAt: '2024-01-21'
  }, {
    id: 'job5',
    jobNumber: 'BRAN-002',
    name: 'Brand Guidelines',
    description: 'Complete brand book',
    projectId: 'proj2',
    status: 'On Hold',
    assignments: {
      PM: 'p9',
      Traffic: 'p1',
      ECD: 'p2',
      CD: 'p3',
      Copywriter: 'p4',
      Designer: 'p5',
      QA: 'p6',
      Client: 'p7',
      Producer: 'p8'
    },
    dueDate: '2024-02-28',
    order: 1,
    createdAt: '2024-01-22'
  }],
  assets: [{
    id: 'a1',
    name: 'Hero Video 60s',
    type: 'video',
    templateId: 'video-edit-long',
    jobId: 'job1',
    projectId: 'proj1',
    status: 'In Progress',
    assignedTo: 'p8',
    dueDate: '2024-02-12',
    order: 0
  }, {
    id: 'a2',
    name: 'Hero Video 30s',
    type: 'video',
    templateId: 'video-edit-short',
    jobId: 'job1',
    projectId: 'proj1',
    status: 'Inbox',
    assignedTo: 'p8',
    dueDate: '2024-02-14',
    order: 1
  }, {
    id: 'a3',
    name: 'Instagram Post 1',
    type: 'image',
    templateId: 'social-static',
    jobId: 'job2',
    projectId: 'proj1',
    status: 'Today',
    assignedTo: 'p5',
    dueDate: '2024-02-08',
    order: 0
  }, {
    id: 'a4',
    name: 'Instagram Post 2',
    type: 'image',
    templateId: 'social-static',
    jobId: 'job2',
    projectId: 'proj1',
    status: 'Today',
    assignedTo: 'p5',
    dueDate: '2024-02-08',
    order: 1
  }, {
    id: 'a5',
    name: 'Instagram Story',
    type: 'video',
    templateId: 'social-story',
    jobId: 'job2',
    projectId: 'proj1',
    status: 'Inbox',
    assignedTo: 'p5',
    dueDate: '2024-02-09',
    order: 2
  }, {
    id: 'a6',
    name: 'Welcome Email',
    type: 'document',
    templateId: 'email-template',
    jobId: 'job3',
    projectId: 'proj1',
    status: 'Inbox',
    assignedTo: 'p4',
    dueDate: '2024-02-18',
    order: 0
  }, {
    id: 'a7',
    name: 'Logo Concept A',
    type: 'image',
    templateId: 'presentation',
    jobId: 'job4',
    projectId: 'proj2',
    status: 'In Review',
    assignedTo: 'p3',
    dueDate: '2024-02-03',
    order: 0
  }, {
    id: 'a8',
    name: 'Logo Concept B',
    type: 'image',
    templateId: 'presentation',
    jobId: 'job4',
    projectId: 'proj2',
    status: 'In Review',
    assignedTo: 'p5',
    dueDate: '2024-02-03',
    order: 1
  }],
  tasks: [
  // Job 1 - Hero Video tasks
  {
    id: 't1',
    templateId: 'copy',
    jobId: 'job1',
    status: 'Done',
    assignedTo: 'p4',
    characterCount: 245,
    content: 'Summer is here! Experience the thrill...',
    fileUrl: null,
    fileType: null,
    completedAt: '2024-01-20',
    order: 0
  }, {
    id: 't2',
    templateId: 'media',
    jobId: 'job1',
    status: 'In Progress',
    assignedTo: 'p5',
    characterCount: null,
    content: null,
    fileUrl: 'hero-video-draft.mp4',
    fileType: 'video',
    completedAt: null,
    order: 1
  },
  // Job 2 - Social Package tasks
  {
    id: 't3',
    templateId: 'copy',
    jobId: 'job2',
    status: 'In Progress',
    assignedTo: 'p4',
    characterCount: 180,
    content: 'Get ready for summer vibes...',
    fileUrl: null,
    fileType: null,
    completedAt: null,
    order: 0
  }, {
    id: 't4',
    templateId: 'media',
    jobId: 'job2',
    status: 'Inbox',
    assignedTo: 'p5',
    characterCount: null,
    content: null,
    fileUrl: null,
    fileType: null,
    completedAt: null,
    order: 1
  },
  // Job 3 - Email Campaign tasks
  {
    id: 't5',
    templateId: 'copy',
    jobId: 'job3',
    status: 'Inbox',
    assignedTo: 'p4',
    characterCount: null,
    content: null,
    fileUrl: null,
    fileType: null,
    completedAt: null,
    order: 0
  }, {
    id: 't6',
    templateId: 'media',
    jobId: 'job3',
    status: 'Inbox',
    assignedTo: 'p5',
    characterCount: null,
    content: null,
    fileUrl: null,
    fileType: null,
    completedAt: null,
    order: 1
  },
  // Job 4 - Logo Design tasks
  {
    id: 't7',
    templateId: 'copy',
    jobId: 'job4',
    status: 'Done',
    assignedTo: 'p4',
    characterCount: 50,
    content: 'TechStart - Innovation Forward',
    fileUrl: null,
    fileType: null,
    completedAt: '2024-01-25',
    order: 0
  }, {
    id: 't8',
    templateId: 'media',
    jobId: 'job4',
    status: 'In Review',
    assignedTo: 'p5',
    characterCount: null,
    content: null,
    fileUrl: 'logo-concepts.png',
    fileType: 'image',
    completedAt: null,
    order: 1
  },
  // Job 5 - Brand Guidelines tasks
  {
    id: 't9',
    templateId: 'copy',
    jobId: 'job5',
    status: 'On Hold',
    assignedTo: 'p4',
    characterCount: null,
    content: null,
    fileUrl: null,
    fileType: null,
    completedAt: null,
    order: 0
  }, {
    id: 't10',
    templateId: 'media',
    jobId: 'job5',
    status: 'On Hold',
    assignedTo: 'p5',
    characterCount: null,
    content: null,
    fileUrl: null,
    fileType: null,
    completedAt: null,
    order: 1
  }],
  wikiPages: [{
    id: 'wiki1',
    title: 'Acme Corp',
    slug: 'acme-corp',
    content: '<h1>Acme Corp Client Bible</h1><h2>Brand Overview</h2><p>Acme Corp is a leading provider of innovative solutions. Founded in 1985, they have grown to serve millions of customers worldwide.</p><h2>Key Contacts</h2><ul><li><strong>Marketing Director:</strong> John Smith (john@acme.com)</li><li><strong>Brand Manager:</strong> Jane Doe (jane@acme.com)</li></ul><h2>Brand Colors</h2><p><strong>Primary:</strong> #FF5733 (Acme Orange)</p><p><strong>Secondary:</strong> #333333 (Charcoal)</p>',
    templateId: 'client-bible',
    parentId: null,
    type: 'client',
    linkedJobs: [],
    linkedProjects: ['proj1'],
    tags: ['client', 'brand'],
    createdAt: '2024-01-10',
    updatedAt: '2024-01-15',
    createdBy: 'p1',
    order: 0
  }, {
    id: 'wiki2',
    title: 'Summer Campaign 2024',
    slug: 'summer-campaign-2024',
    content: '<h1>Summer Campaign 2024</h1><h2>Campaign Overview</h2><p><strong>Launch Date:</strong> June 1, 2024</p><p><strong>Objective:</strong> Drive awareness and sales for Q3 product line</p><h2>Target Audience</h2><p>Adults 25-45, urban professionals, household income $75k+</p><h2>Creative Approach</h2><p>Bright, energetic visuals emphasizing summer lifestyle and product benefits.</p>',
    templateId: 'campaign-log',
    parentId: 'wiki1',
    type: 'campaign',
    linkedJobs: ['job1', 'job2', 'job3'],
    linkedProjects: ['proj1'],
    tags: ['campaign', 'summer', '2024'],
    createdAt: '2024-01-16',
    updatedAt: '2024-01-20',
    createdBy: 'p1',
    order: 0
  }, {
    id: 'wiki3',
    title: 'TechStart',
    slug: 'techstart',
    content: '<h1>TechStart Client Bible</h1><h2>Brand Overview</h2><p>TechStart is a disruptive tech startup focused on B2B solutions.</p><h2>Tone of Voice</h2><p>Professional yet approachable. Innovative but not jargon-heavy.</p>',
    templateId: 'client-bible',
    parentId: null,
    type: 'client',
    linkedJobs: [],
    linkedProjects: ['proj2'],
    tags: ['client', 'tech'],
    createdAt: '2024-01-20',
    updatedAt: '2024-01-20',
    createdBy: 'p9',
    order: 1
  }, {
    id: 'wiki4',
    title: 'Cannes Lions 2024',
    slug: 'cannes-lions-2024',
    content: '<h1>Cannes Lions 2024 Entry</h1><h2>Award Details</h2><p><strong>Category:</strong> Digital Craft</p><p><strong>Deadline:</strong> March 15, 2024</p><h2>Campaign</h2><p>Summer Campaign Hero Video for Acme Corp</p><h2>Status</h2><p>In preparation</p>',
    templateId: 'award-submission',
    parentId: null,
    type: 'award',
    linkedJobs: ['job1'],
    linkedProjects: ['proj1'],
    tags: ['awards', 'cannes', '2024'],
    createdAt: '2024-01-25',
    updatedAt: '2024-01-25',
    createdBy: 'p2',
    order: 0
  }],
  scheduledEmails: []
});

// ============================================================================
// STATE MANAGEMENT
// ============================================================================

const STORAGE_KEY = 'slash301pm_data';
const loadFromStorage = () => {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      let data = JSON.parse(saved);
      // Check and run migrations if needed
      const migratedData = migrateData(data);
      // Save migrated data if version changed
      if (migratedData._schemaVersion !== data._schemaVersion) {
        saveToStorage(migratedData);
      }
      return migratedData;
    }
  } catch (e) {
    console.error('Failed to load from storage:', e);
  }
  return createInitialData();
};
const saveToStorage = data => {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    return {
      success: true
    };
  } catch (e) {
    console.error('Failed to save to storage:', e);

    // Handle QuotaExceededError
    if (e.name === 'QuotaExceededError' || e.code === 22 ||
    // Legacy Chrome
    e.code === 1014 ||
    // Legacy Firefox
    e.name === 'NS_ERROR_DOM_QUOTA_REACHED') {
      return {
        success: false,
        error: 'quota_exceeded',
        message: 'Storage quota exceeded. Your data may not be saved.'
      };
    }
    return {
      success: false,
      error: 'unknown',
      message: 'Failed to save data: ' + e.message
    };
  }
};

// Track last storage error for UI notification
let lastStorageError = null;
const getLastStorageError = () => lastStorageError;
const clearLastStorageError = () => {
  lastStorageError = null;
};
const dataReducer = (state, action) => {
  let newState;
  switch (action.type) {
    case 'SET_DATA':
      newState = action.payload;
      break;
    case 'ADD_PROJECT':
      newState = {
        ...state,
        projects: [...state.projects, action.payload]
      };
      break;
    case 'UPDATE_PROJECT':
      newState = {
        ...state,
        projects: state.projects.map(p => p.id === action.payload.id ? action.payload : p)
      };
      break;
    case 'DELETE_PROJECT': {
      const projectJobIds = state.jobs.filter(j => j.projectId === action.payload).map(j => j.id);
      newState = {
        ...state,
        projects: state.projects.filter(p => p.id !== action.payload),
        jobs: state.jobs.filter(j => j.projectId !== action.payload),
        assets: state.assets.filter(a => !projectJobIds.includes(a.jobId)),
        tasks: (state.tasks || []).filter(t => !projectJobIds.includes(t.jobId))
      };
      break;
    }
    case 'ADD_JOB':
      newState = {
        ...state,
        jobs: [...state.jobs, action.payload]
      };
      break;
    case 'UPDATE_JOB':
      newState = {
        ...state,
        jobs: state.jobs.map(j => j.id === action.payload.id ? action.payload : j)
      };
      break;
    case 'DELETE_JOB':
      newState = {
        ...state,
        jobs: state.jobs.filter(j => j.id !== action.payload),
        assets: state.assets.filter(a => a.jobId !== action.payload),
        tasks: (state.tasks || []).filter(t => t.jobId !== action.payload)
      };
      break;
    case 'REORDER_JOBS':
      newState = {
        ...state,
        jobs: action.payload
      };
      break;
    case 'ADD_ASSET':
      newState = {
        ...state,
        assets: [...state.assets, action.payload]
      };
      break;
    case 'UPDATE_ASSET':
      newState = {
        ...state,
        assets: state.assets.map(a => a.id === action.payload.id ? action.payload : a)
      };
      break;
    case 'DELETE_ASSET':
      newState = {
        ...state,
        assets: state.assets.filter(a => a.id !== action.payload)
      };
      break;
    case 'REORDER_ASSETS':
      newState = {
        ...state,
        assets: action.payload
      };
      break;
    case 'ADD_PERSON':
      newState = {
        ...state,
        people: [...state.people, action.payload]
      };
      break;
    case 'UPDATE_PERSON':
      newState = {
        ...state,
        people: state.people.map(p => p.id === action.payload.id ? action.payload : p)
      };
      break;
    case 'DELETE_PERSON': {
      const personId = action.payload;
      newState = {
        ...state,
        people: state.people.filter(p => p.id !== personId),
        jobs: state.jobs.map(j => {
          if (!j.assignments) return j;
          const cleaned = { ...j.assignments };
          Object.keys(cleaned).forEach(role => {
            if (cleaned[role] === personId) delete cleaned[role];
          });
          return { ...j, assignments: cleaned };
        }),
        assets: state.assets.map(a =>
          a.assignedTo === personId ? { ...a, assignedTo: null } : a
        )
      };
      break;
    }
    // Wiki actions
    case 'ADD_WIKI_PAGE':
      newState = {
        ...state,
        wikiPages: [...(state.wikiPages || []), action.payload]
      };
      break;
    case 'UPDATE_WIKI_PAGE':
      newState = {
        ...state,
        wikiPages: (state.wikiPages || []).map(p => p.id === action.payload.id ? action.payload : p)
      };
      break;
    case 'DELETE_WIKI_PAGE':
      newState = {
        ...state,
        wikiPages: (state.wikiPages || []).filter(p => p.id !== action.payload)
      };
      break;
    // Scheduled email actions
    case 'ADD_SCHEDULED_EMAIL':
      newState = {
        ...state,
        scheduledEmails: [...(state.scheduledEmails || []), action.payload]
      };
      break;
    case 'DELETE_SCHEDULED_EMAIL':
      newState = {
        ...state,
        scheduledEmails: (state.scheduledEmails || []).filter(e => e.id !== action.payload)
      };
      break;
    // Task actions
    case 'ADD_TASK':
      newState = {
        ...state,
        tasks: [...(state.tasks || []), action.payload]
      };
      break;
    case 'UPDATE_TASK':
      newState = {
        ...state,
        tasks: (state.tasks || []).map(t => t.id === action.payload.id ? action.payload : t)
      };
      break;
    case 'DELETE_TASK':
      newState = {
        ...state,
        tasks: (state.tasks || []).filter(t => t.id !== action.payload)
      };
      break;
    default:
      return state;
  }
  const saveResult = saveToStorage(newState);
  if (!saveResult.success) {
    lastStorageError = saveResult;
  }
  return newState;
};
